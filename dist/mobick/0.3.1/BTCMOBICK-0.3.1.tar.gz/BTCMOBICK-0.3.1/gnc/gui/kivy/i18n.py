import gettext

from gnc.logging import get_logger


_logger = get_logger(__name__)


class _(str):

    observers = set()
    lang = None

    def __new__(cls, s):
        if _.lang is None:
            _.switch_lang('en')
        t = _.translate(s)
        o = super(_, cls).__new__(cls, t)
        o.source_text = s
        return o

    @staticmethod
    def translate(s, *args, **kwargs):
        return _.lang(s)

    @staticmethod
    def bind(label):
        try:
            _.observers.add(label)
        except Exception:
            pass
        # garbage collection
        new = set()
        for label in _.observers:
            try:
                new.add(label)
            except Exception:
                pass
        _.observers = new

    @staticmethod
    def switch_lang(lang):
        _logger.info(f"switch_lang() called with {lang=!r}")
        # get the right locales directory, and instantiate a gettext
        from gnc.i18n import LOCALE_DIR, set_language
        locales = gettext.translation('gnc', LOCALE_DIR, languages=[lang], fallback=True)
        _.lang = locales.gettext
        for label in _.observers:
            try:
                label.text = _(label.text.source_text)
            except Exception:
                pass
        # Note that all invocations of _() inside the core gnc library
        # use gnc.i18n instead of gnc.gui.kivy.i18n, so we should update the
        # language there as well:
        set_language(lang)
