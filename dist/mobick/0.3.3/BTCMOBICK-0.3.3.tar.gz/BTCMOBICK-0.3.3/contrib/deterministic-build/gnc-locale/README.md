# electrum-locale

This repository contains frozen translations for [Electrum](https://github.com/spesmilo/electrum),
used for reproducible/deterministic builds.

If you would like to help in contributing translations, please
[visit crowdin](https://crowdin.com/project/electrum) instead.
