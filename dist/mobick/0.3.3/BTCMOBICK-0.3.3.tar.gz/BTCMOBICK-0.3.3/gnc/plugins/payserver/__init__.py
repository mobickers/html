from gnc.i18n import _

fullname = _('PayServer')
description = 'run a HTTP server for receiving payments'
available_for = ['qt', 'cmdline']
